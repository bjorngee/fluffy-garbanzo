Config = {}

Config.DistressBlip = {
	Sprite = 310,
	Color = 48,
	Scale = 0.6
}

Config.zoom = {
	min = 1, 
	max = 6, 
	step = 0.5
}

Config.Ambulance = {
    HPBlip = {
        pos = vec3(-493.9155, -993.3374, 24.2893),
        label = '[~r~Los Santos~w~]: Hospital',
        id = 61,
        scale = 0.6,
        colour = 1
    },

    RespawnFineAmount = 5000, -- Respawn Fine Amount
    RespawnTimer = 60000 * 3, -- 5 Minutes Respawn Timer
    TraphouseRespawnTimer = 60000 * 0.5, -- 2 Minutes Respawn Timer
    BleedoutTimer = 60000 * 30, -- 30 Minutes Bleedout Timer
    SpawnerSelector = {
        {
            name = 'Neptune\'s Haven(GWC)',
            coords = vec4(-742.6423, 374.7999, 87.8754, 179.1786)
        },
        {
            name = 'Rain\'s Casino(MPARK)',
            coords = vec4(885.6481, 0.1704, 78.7647, 145.0397)
        },
        {
            name = 'RaixStar Ammunition(Del Perro)',
            coords = vec4(-1317.9852, -390.9762, 36.4125, 77.0731)
        },
        {
            name = 'Chinie\'s Garage(Pill Box Garage)',
            coords = vec4(231.7171, -760.8702, 30.8322, 156.0187)
        },
        {
            name = 'XaeBu Adobo(Decker St)',
            coords = vec4(-816.4796, -743.1497, 23.7044, 179.4295)
        },
        {
            name = 'Ilsa\'s Hospital(Aldore Hospital)',
            coords = vec4(-464.9471, -1021.1609, 24.2887, 353.7021)
        },
    },
    PoliceSpawn = vec4(-598.7511, -425.3605, 31.1603, 280.4828),
    GangSpawn = {
        gang1 = vec4(-345.6308, 34.2506, 47.8589, 164.8878),
        gang2 = vec4(393.9976, 41.2772, 91.6737, 137.1712),
        gang3 = vec4(-1229.0966, -177.2140, 39.3256, 239.7614),
        gang4 = vec4(-584.4277, 207.1985, 74.1713, 178.9505),
        gang5 = vec4(-1187.6713, -720.2164, 21.1777, 126.8780),
        gang6 = vec4(-1523.1514, 98.7514, 56.7103, 131.6944),
        gang7 = vec4(-191.0046, -1556.7533, 34.9553, 314.2159),
        gang8 = vec4(161.3648, 177.2116, 105.2434, 75.9179),
        gang9 = vec4(-864.2590, -42.7582, 39.4149, 112.5394),
        gang10 = vec4(-1100.0599, -453.2088, 35.4213, 294.2724),
        gang11 = vec4(-585.2733, 320.0973, 84.9542, 264.2947),
        gang12 = vec4(721.6031, -1070.5530, 23.0623, 86.0201),
        gang13 = vec4(-1829.9940, 326.4807, 90.0684, 99.5110),
        gang14 = vec4(-632.6663, -113.9302, 38.0586, 87.6281),
        gang15 = vec4(-220.6572, -1310.5337, 31.2922, 359.6897),
        gang16 = vec4(-676.5417, -879.7661, 24.4483, 97.0852),
        gang17 = vec4(-731.2072, -1300.5582, 5.0502, 56.4566),
        gang18 = vec4(-465.9128, -41.1773, 44.7712, 173.6698),
        gang19 = vec4(-1183.5879, -1502.8412, 4.3797, 208.3516),
        gang20 = vec4(-2193.0354, -418.7623, 13.0962, 312.4143),
        gang21 = vec4(80.6587, 266.7261, 109.4745, 153.6123),
        gang22 = vec4(115.1361, -1948.3184, 20.6251, 48.2566),
    },
    --[[RECOVERY STATE]]--
    RecoverySystem = true, -- Enable/Disable Recovery System
    RecoveryStateAfterNewLife = 60, -- Recovery Timer in Seconds
    RecoveryStateAfterTreat = 60,

    --[[EMS ACTIONS]]--
    ReviveReward = true, -- Enable/Disable Revive Reward
    ReviveRewardAmount = 1000, -- Reward after reviving

    --[[Stretcher Menu]]--
    StretcherVehicles = {
        "ambulance",
    },
    --[[Custom Stash]]--
    Stashes = {
        {
            id = 'ems_stash',
            label = 'EMS Stash',
            owner = false,
            slots = 1000,
            weight = 10000000
        },
        {
            id = 'ems_locker',
            label = 'EMS Personal Stash',
            owner = true,
            slots = 100,
            weight = 100000
        }
    },
    --[[BED SYSTEM]]--
    BedLocations = {
        vec4(-12.6620, -596.9390, 38.7273, 75.2652),
        vec4(-11.4154, -593.8101, 38.7271, 75.8275),
        vec4(-10.2600, -590.5906, 38.7274, 77.9788),
        vec4(-8.8646, -587.0321, 38.7274, 77.2634),
        vec4(-7.5656, -583.4234, 38.7274, 78.0487),
        vec4(-12.5241, -581.7808, 38.7274, 257.2026),
    },
    BedConfig = {
        TriedToGetUpDay = 1
    } 
}

