




fx_version 'cerulean'
games {'gta5'}
author 'BG Development'
description 'SEAN-EMS'
version 'SEAN-V2'
lua54 'yes'
files {
    'locales/en.json'
}
shared_scripts{
    '@es_extended/imports.lua',
    '@ox_lib/init.lua'
}
client_scripts{
    'config.lua',
    'client/utils.lua',
    'client/main.lua',
    'client/job.lua',
    'client/stretcher.lua',
    'client/med.lua',
    'client/deathcause.lua',
    'client/wardrobe.lua',
    'client/bed.lua'
}
server_scripts{
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server/main.lua'
}
escrow_ignore {
    'config.lua'
}
dependency '/assetpacks'