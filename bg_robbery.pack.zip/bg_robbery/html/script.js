window.addEventListener('message', function(event) {
    const item = event.data;
    
    if (item.action === 'showLeaderboard') {
        document.getElementById('leaderboard').style.display = 'flex';
    } else if (item.action === 'updateLeaderboard') {
        updateLeaderboard(item.data);
    } else if (item.action === 'updatePlayerStats') {
        updatePlayerStats(item.stats);
    }
});         

document.getElementById('closeButton').addEventListener('click', function() {
    document.getElementById('leaderboard').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/closeLeaderboard`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({})
    });
});

function updatePlayerStats(stats) {
    document.getElementById('playerKills').textContent = `Kills: ${stats.kills}`;
    document.getElementById('playerDeaths').textContent = `Deaths: ${stats.deaths}`;
    const kd = stats.deaths > 0 ? (stats.kills / stats.deaths).toFixed(2) : stats.kills.toFixed(2);
    document.getElementById('playerKD').textContent = `K/D: ${kd}`;
}

function updateLeaderboard(data) {
    const tbody = document.getElementById('leaderboardBody');
    tbody.innerHTML = '';
    
    data.forEach((player, index) => {
        const row = document.createElement('tr');
        const kd = (player.deaths > 0) ? (player.kills / player.deaths).toFixed(2) : player.kills.toFixed(2);
        
        row.innerHTML = `
            <td>#${index + 1}</td>
            <td>${player.firstname} ${player.lastname}</td>
            <td>${player.kills}</td>
            <td>${player.deaths}</td>
            <td>${kd}</td>
        `;
        tbody.appendChild(row);
    });

    if (data.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="6" style="text-align: center">No data available</td>';
        tbody.appendChild(row);
    }
}