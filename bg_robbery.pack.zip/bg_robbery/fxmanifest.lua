

fx_version 'cerulean'
games {'gta5'}
lua54 'yes'
shared_scripts{
	'@oxmysql/lib/MySQL.lua',
    "@mysql-async/lib/MySQL.lua",
    '@ox_lib/init.lua',
    '@es_extended/imports.lua',
    'config.lua'
}
client_scripts{
    '@es_extended/locale.lua',
    'locales/en.lua',
    'configs/*.lua',
    'utils/utils.lua',
    'client/**/*.lua'
}
server_script{
    '@es_extended/locale.lua',
    "@mysql-async/lib/MySQL.lua",
    'locales/en.lua',
    'configs/*.lua',
    'server/**/*.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
dependency '/assetpacks'